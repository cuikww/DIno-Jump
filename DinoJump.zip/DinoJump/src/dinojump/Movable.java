package dinojump;

public interface Movable {
    // void update();
    void moveDown(int dy);
}
